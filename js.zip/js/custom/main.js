var HOST_URL = "index.html";
function onClickHeaderHome() {
    location.href = HOST_URL;
}

function onClickHeaderAbout() {
    location.href ='about.html';
}

function onClickHeaderRecruitment() {
    location.href = 'recruitment.html';
}
function onClickHeaderProduct() {
    location.href = 'product.html';
}

function onClickHeaderContact() {
    location.href = 'contact.html';
}

function onClickHeaderPolicy() {
    location.href = 'privacy-policy.html';
}

function onClickHeaderTermOfService() {
    location.href = 'term-of-service.html';
}